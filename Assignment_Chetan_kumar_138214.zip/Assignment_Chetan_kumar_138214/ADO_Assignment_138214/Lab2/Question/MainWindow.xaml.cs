﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace Question
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_20Sep17_Pune_Batch_I;Persist Security Info=True;User ID=sqluser;Password=sqluser");
            con.Open();
            ds = new DataSet();

            // select for data retrieval
            da = new SqlDataAdapter("SELECT * FROM applicationusers", con);
            
            // saving changes back to the database
            SqlCommandBuilder bld = new SqlCommandBuilder(da);
            da.Fill(ds,"appusers");
            dgUsers.ItemsSource = ds.Tables["appusers"].DefaultView;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // save changes to database
                da.Update(ds.Tables["appusers"]);
                MessageBox.Show("Changes Saved");
            }
            catch(SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            ds.Tables["appusers"].RejectChanges();
        }
    }
}
