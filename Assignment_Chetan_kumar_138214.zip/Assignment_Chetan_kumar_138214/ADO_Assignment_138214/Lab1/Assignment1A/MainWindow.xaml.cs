﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment1A
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // inserting into table Employee_ADO1
                SqlCommand cmd = new SqlCommand("insert into Employee_ADO1 values(@eno,@empname,@empsal,@emptype)", con);

                //the parameters
                cmd.Parameters.Add("@eno", System.Data.SqlDbType.Int);
                cmd.Parameters.Add("@empname", System.Data.SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@empsal", System.Data.SqlDbType.Decimal);
                cmd.Parameters.Add("@emptype", System.Data.SqlDbType.VarChar, 1);

                // assigning the values to parameters
                cmd.Parameters["@eno"].Value = txtEmpno.Text;
                cmd.Parameters["@empname"].Value = txtEmpname.Text;
                cmd.Parameters["@empsal"].Value = txtSalary.Text;
                cmd.Parameters["@emptype"].Value = rdPayroll.IsChecked == true ? "P" : "C";

                // execute insert
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee details saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            txtEmpno.Text = "";
            txtEmpname.Text = "";
            txtSalary.Text = "";
            txtEmpno.Focus();
        }

        private void btnQuerry_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SqlDataReader dReader = null;
                // The procedure to execute
                SqlCommand cmd = new SqlCommand("GetEmployeeById_ADO1", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                //define procedure parameter
                SqlParameter prm;
                prm = new SqlParameter();
                prm.SqlDbType = System.Data.SqlDbType.Int;
                prm.Direction = System.Data.ParameterDirection.Input;
                prm.ParameterName = "@eno";
                cmd.Parameters.Add(prm);

                // assigning parameter value
                cmd.Parameters["@eno"].Value = int.Parse(txtEmpno.Text);

                // execute
                dReader = cmd.ExecuteReader();

                // if employee record found
                if (dReader.Read())
                {
                    txtEmpname.Text = dReader["empname"].ToString();
                    txtSalary.Text = dReader["empsal"].ToString();
                    if (dReader["emptype"].ToString() == "P")
                    {
                        rdPayroll.IsChecked = true;
                    }
                    else
                    {
                        rdConsultant.IsChecked = true;
                    }
                }
                else
                {
                    btnNew_Click(btnNew, e);
                    MessageBox.Show("No such employee");
                }
                dReader.Close();

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_20Sep17_Pune_Batch_I;Persist Security Info=True;User ID=sqluser;Password=sqluser");

            con.Open();
        }

        SqlConnection con;

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

            MessageBoxResult result = MessageBox.Show("Do you really want to delete!!");
            if(result == MessageBoxResult.OK)
            {
                try
                {
                    // The procedure to execute
                    SqlCommand cmd = new SqlCommand("DeleteEmployeeById_ADO1", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    //define procedure parameter
                    SqlParameter prm;
                    prm = new SqlParameter();
                    prm.SqlDbType = System.Data.SqlDbType.Int;
                    prm.Direction = System.Data.ParameterDirection.Input;
                    prm.ParameterName = "@empno";
                    cmd.Parameters.Add(prm);

                    // assigning parameter value
                    cmd.Parameters["@empno"].Value = int.Parse(txtEmpno.Text);

                    // execute
                    cmd.ExecuteNonQuery();

                    // if employee record found
                    
                    

                }
                catch (SqlException sqlex)
                {
                    MessageBox.Show(sqlex.Message);
                }

                MessageBox.Show("Employee Deleted");
            }
        }
    }
}
