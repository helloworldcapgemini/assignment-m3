﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        SqlConnection con;

        private void btnQuerry_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SqlDataReader dReader = null;
                // The procedure to execute
                SqlCommand cmd = new SqlCommand("GetEmployeeById_ADO1", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                //define procedure parameter
                SqlParameter prm;
                prm = new SqlParameter();
                prm.SqlDbType = System.Data.SqlDbType.Int;
                prm.Direction = System.Data.ParameterDirection.Input;
                prm.ParameterName = "@eno";
                cmd.Parameters.Add(prm);

                // assigning parameter value
                cmd.Parameters["@eno"].Value = int.Parse(txtEmpno.Text);

                // execute
                dReader = cmd.ExecuteReader();

                // if employee record found
                if (dReader.Read())
                {
                    txtEmpname.Text = dReader["empname"].ToString();
                    txtSalary.Text = dReader["empsal"].ToString();
                    if (dReader["emptype"].ToString() == "P")
                    {
                        rdPayroll.IsChecked = true;
                    }
                    else
                    {
                        rdConsultant.IsChecked = true;
                    }
                }
                else
                {
                    btnNew_Click(btnNew, e);
                    MessageBox.Show("No such employee");
                }
                dReader.Close();

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            txtEmpno.Text = "";
            txtEmpname.Text = "";
            txtSalary.Text = "";
            txtEmpno.Focus();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // inserting into table Employee_ADO1
                SqlCommand cmd = new SqlCommand("AddNewEmployee_ADO1", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                //define procedure parameter
                SqlParameter prm1,prm2,prm3;
                prm1 = new SqlParameter();
                prm1.SqlDbType = System.Data.SqlDbType.VarChar;
                prm1.Direction = System.Data.ParameterDirection.Input;
                prm1.ParameterName = "@empname";
                cmd.Parameters.Add(prm1);

                prm2 = new SqlParameter();
                prm2.SqlDbType = System.Data.SqlDbType.Decimal;
                prm2.Direction = System.Data.ParameterDirection.Input;
                prm2.ParameterName = "@empsal";
                cmd.Parameters.Add(prm2);

                prm3 = new SqlParameter();
                prm3.SqlDbType = System.Data.SqlDbType.VarChar;
                prm3.Direction = System.Data.ParameterDirection.Input;
                prm3.ParameterName = "@emptype";
                cmd.Parameters.Add(prm3);

                // assigning parameter value
                cmd.Parameters["@empname"].Value = txtEmpname.Text;
                cmd.Parameters["@empsal"].Value = decimal.Parse(txtSalary.Text);
                cmd.Parameters["@emptype"].Value = rdPayroll.IsChecked == true ? "P" : "C";


                // execute
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee details saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_20Sep17_Pune_Batch_I;Persist Security Info=True;User ID=sqluser;Password=sqluser");

            con.Open();
        }
    }
}
