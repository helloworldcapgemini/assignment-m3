﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ADO6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        SqlConnection cn;
        SqlDataAdapter da;
        DataSet ds = new DataSet();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
            cn.Open();
            da = new SqlDataAdapter("select * from applicationusers",cn);
            
            SqlCommandBuilder cmdbud = new SqlCommandBuilder(da);
            
        }

        private void ldfrmdb_Click(object sender, RoutedEventArgs e)
        {
            da.Fill(ds, "jklm");
            dgshow.ItemsSource = ds.Tables["jklm"].DefaultView;
            ldfrmdb.IsEnabled = false;
        }

        private void savxml_Click(object sender, RoutedEventArgs e)
        {
            ds.Tables["jklm"].WriteXmlSchema(@"D:\\phani.xsd");
            ds.Tables["jklm"].WriteXml(@"D:\\phani.xml",XmlWriteMode.DiffGram);
            MessageBox.Show("Saved to XML");
        }

        private void ldfrmXML_Click(object sender, RoutedEventArgs e)
        {
            ds.Tables["jklm"].ReadXmlSchema(@"D:\\phani.xsd");
            ds.Tables["jklm"].ReadXml(@"D:\\phani.xml");
            MessageBox.Show("Loaded from xml");
            dgshow.Items.Clear();
            dgshow.ItemsSource=ds.Tables["jklm"].DefaultView;
        }

        private void savtodb_Click(object sender, RoutedEventArgs e)
        {
            
            da.Update(ds.Tables["jklm"]);
            
            MessageBox.Show("Lodaded into db");
        }
    }


}
