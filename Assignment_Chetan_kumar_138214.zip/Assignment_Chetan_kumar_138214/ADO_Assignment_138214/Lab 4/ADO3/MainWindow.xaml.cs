﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ADO3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string conString = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
        public MainWindow()
        {
            InitializeComponent();
        }
        SqlConnection cn;
        SqlDataAdapter da;
        DataSet ds = new DataSet();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cn = new SqlConnection(conString);
            cn.Open();
            da = new SqlDataAdapter("select * from customer_1382181",cn);
            SqlCommandBuilder cmdbud=new SqlCommandBuilder(da);
            da.Fill(ds, "Customers");
            //string [] ele={"150","Phani","Pune","100.5"};
            //ds.Tables["Customers"].Rows[0].ItemArray=ele;
            grdCustomers.ItemsSource = ds.Tables["Customers"].DefaultView;
        }

        private void cmbcolumnlist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ds.Tables["Customers"].DefaultView.Sort = cmbcolumnlist.Text;
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            ds.Tables["Customers"].DefaultView.RowFilter = "City like  '"+ txtCity.Text + "'";
        }
    }
}
