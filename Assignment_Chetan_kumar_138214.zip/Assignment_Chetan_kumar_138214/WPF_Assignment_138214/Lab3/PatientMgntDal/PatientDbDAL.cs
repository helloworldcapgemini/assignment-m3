﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDetails;
using System.Data;
using System.Data.SqlClient;

namespace PatientMgntDal
{
    public class PatientDbDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public PatientDbDAL(string conString)
        {
            cn = new SqlConnection(conString);
        }

       
        public List<Patient> GetAll()
        {
            
            List<Patient> ptn = new List<Patient>();
            cmd = new SqlCommand("Select * from Patient_138231",cn);
            cn.Open();
            dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                Patient p = new Patient();
                p.PatientId = Convert.ToInt32(dr["PatientId"]);
                p.PatientName = dr["PatientName"].ToString();
                p.PatientCategory = (PatientType)Enum.Parse(typeof(PatientType),dr["PatientType"].ToString());
                ptn.Add(p);
            }
            dr.Close();
            cn.Close();
            return ptn;
        }

        public bool AddPatient(Patient ptn)
        {
            bool added=false;
            try
            {
                cmd = new SqlCommand("Insert into Patient_138231(PatientId,PatientName,PatientType) values(@PatientId,@PatientName,@PatientType)",cn);
                cmd.Parameters.AddWithValue("@PatientName", ptn.PatientName);
                cmd.Parameters.AddWithValue("@PatientId", ptn.PatientId);
                cmd.Parameters.AddWithValue("@PatientType",ptn.PatientCategory);
                cn.Open();
                cmd.ExecuteNonQuery();
                added = true;
            }
            catch (Exception)
            {
                
                throw;
            }
            finally
            {
                cn.Close();
                
            }
            return added;
        }
    }
}
