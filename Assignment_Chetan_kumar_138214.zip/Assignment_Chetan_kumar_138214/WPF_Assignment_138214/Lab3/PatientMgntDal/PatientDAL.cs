﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using PatientDetails;


namespace PatientMgntDal
{
    public class PatientDAL
    {

        private ObservableCollection<Patient> Patient;
        public PatientDAL()
        {
             
        }
        
        public ObservableCollection<Patient>  Patients()
        {
            Patient = new ObservableCollection<Patient>()
            {
                new Patient(){PatientId=1100, PatientName="jatin", PatientCategory=(PatientType)0},
                new Patient(){PatientId=1229, PatientName="agralkjhf", PatientCategory=(PatientType)0},
                new Patient(){PatientId=1333, PatientName="dfjhgfsiu", PatientCategory=(PatientType)1},
            };

            return Patient;
        }
        
    }
}
