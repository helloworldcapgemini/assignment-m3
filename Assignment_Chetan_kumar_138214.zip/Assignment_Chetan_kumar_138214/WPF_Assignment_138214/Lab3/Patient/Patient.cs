﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDetails
{
    public enum PatientType
    {
        IN,OUT
    }
    public class Patient
    {
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public PatientType PatientCategory { get; set; }
    }
}
