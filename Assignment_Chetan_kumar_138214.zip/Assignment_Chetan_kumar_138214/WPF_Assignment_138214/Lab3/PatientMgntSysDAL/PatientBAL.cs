﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientMgntDal;
using PatientDetails;

namespace PatientMgntSysBAL
{
    public class PatientBAL
    {
        PatientDbDAL dal = null;
        PatientDAL dal2 = null;
        public PatientBAL()
        {
            dal2 = new PatientDAL();
            
        }
        
        public PatientBAL(string conString)
        {
            dal = new PatientDbDAL(conString);
        }

        public void Add(Patient p)
        {
            dal.AddPatient(p);
            
        }

        public List<Patient> SelectAll()
        {
            List<Patient> ptn = new List<Patient>();
            ptn=dal.GetAll();
            return ptn;
        }
    }
}
