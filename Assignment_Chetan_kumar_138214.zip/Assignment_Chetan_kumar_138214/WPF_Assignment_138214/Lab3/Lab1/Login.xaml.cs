﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using PatientDetails;
using PatientMgntDal;

namespace Lab1
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        PatientDbDAL dal1 = new PatientDbDAL(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        public Login()
        {
            InitializeComponent();
            
        }
        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            Patient ptn=new Patient();
            ptn.PatientId = int.Parse(PatId.Text);
            ptn.PatientName = pName.Text;
            ptn.PatientCategory = (PatientType)cbType.SelectedIndex;
            if(dal1.AddPatient(ptn))
            {
                MessageBox.Show("Patient Added");
            }

            PopulateUI();
            pName.Text = string.Empty;
            cbType.SelectedIndex = -1;
            
        }

        public void PopulateUI()
        {
            Info.Items.Clear();
            try
            {
                List<Patient> ptnlist = new List<Patient>();
                ptnlist = dal1.GetAll();
                PatientDAL dal2 = new PatientDAL();
                foreach (var item in dal2.Patients())
                {
                    Info.Items.Add("Patient ID : " + item.PatientId + "\nPatient Name : " + item.PatientName + "\nPatient Type : " + item.PatientCategory);
                }

                if(ptnlist!=null)
                {
                    foreach (var item in ptnlist)
                    {
                        Info.Items.Add("Patient ID : " + item.PatientId + "\nPatient Name : " + item.PatientName + "\nPatient Type : " + item.PatientCategory);
                    }
                }
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void TabItem_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        public void RandomId()
        {
            Random rd = new Random();
            int x = rd.Next(1000, 9999);
            int count = 0;
            foreach (var item in dal1.GetAll())
            {
                if (item.PatientId == x)
                {
                    count = 2;
                    break;
                }
            }
            if (count == 0)
            {
                PatId.Text = x.ToString();
            }
            else
            {
                RandomId();
            }
        }

        private void TabItem_Loaded_1(object sender, RoutedEventArgs e)
        {

            RandomId();
        }

        

        
    }
}
