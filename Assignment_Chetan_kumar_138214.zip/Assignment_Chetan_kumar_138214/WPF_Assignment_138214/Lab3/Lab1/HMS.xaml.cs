﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab1
{
    /// <summary>
    /// Interaction logic for HMS.xaml
    /// </summary>
    public partial class HMS : Window
    {
        public HMS()
        {
            InitializeComponent();
        }
        static int count = 0;
        
        

        private void Clear(object sender, RoutedEventArgs e)
        {
            userName.Text = string.Empty;
            Passwrd.Clear();
            userName.Focus();
        }

        private void Login(object sender, RoutedEventArgs e)
        {
            
            string str = Passwrd.Password;
            if(userName.Text.Equals("admin") && str.Equals("admin"))
            {
                Login l = new Login();
                l.Show();
            }
            else
            {
                count++;
                userName.Text = string.Empty;
                Passwrd.Clear();
                userName.Focus();
            }
            if (count >= 3)
            {
                Close();
            }
        }

        private void CheckText(object sender, TextCompositionEventArgs e)
        {
            
            string str=userName.Text;
            for (int i = 0; i < str.Length; i++)
			{
			    if(str[i]<'A')
                {
                    MessageBox.Show("Enter teh correct username with only alphabet");
                    break;
                }
                else if (str[i] > 'z')
                {
                    MessageBox.Show("Enter teh correct username with only alphabet");
                    break;
                }
			}
        }

        private void Window_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            MessageBox.Show("This is Window event");
        }

        private void StackPanel_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            MessageBox.Show("This is StackPanel event");
        }

        
    }
    }

