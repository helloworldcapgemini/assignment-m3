﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductContext context = new ProductContext();

            Product p1 = new Product { ProductID = 101, Name = "Barbie Doll", Category="Toys" , Price=199.99M};
            Product p2 = new Product { ProductID = 102, Name = "Montex Pen", Category = "Stationary", Price = 10.99M };
            context.Products.Add(p1);
            context.Products.Add(p2);

//            context.Products.Add(p1);
//            context.Products.Add(p2);

            context.SaveChanges();

            Console.WriteLine("Products Details Added Successfully");

            Console.ReadKey();

        }
    }
}
