﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstConsoleApp
{
    class ProductContext : DbContext
    {
        public DbSet<Product> Products { get; set; }

        public ProductContext():base("conn")
        {

            //this.Configuration.LazyLoadingEnabled = true;
        }

       
    }
}
