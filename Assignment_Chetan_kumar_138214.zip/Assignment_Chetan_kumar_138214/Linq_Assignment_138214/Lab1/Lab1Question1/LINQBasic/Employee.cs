﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQBasic
{
    class Employee
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public DateTime DOB { get; set; }
        public DateTime DOJ { get; set; }
        public string City { get; set; }

        public override string ToString()
        {
            return "Id: " + EmployeeID + ", First Name: " + FirstName +
                ", Last Name: " + LastName + ", Title: " + Title +
                ", DOB: " + DOB.ToShortDateString().ToString() +
                ", DOJ: " + DOJ.ToShortDateString().ToString() +
                ", City: " + City;

        }
    }
}
