﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQBasic
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> employees = new List<Employee>()
            {
                new Employee{
                    EmployeeID = 1001,
                    FirstName="Malcolm",
                    LastName="Daruwalla",
                    Title="Manager",
                    DOB= DateTime.ParseExact("16/11/1984", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("08/06/2011", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Mumbai"
                },
                new Employee{
                    EmployeeID = 1002,
                    FirstName="Asdin",
                    LastName="Dhalla",
                    Title="AsstManager",
                    DOB= DateTime.ParseExact("20/08/1984", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("07/07/2012", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Mumbai"
                },
                new Employee{
                    EmployeeID = 1003,
                    FirstName="Madhavi",
                    LastName="Oza",
                    Title="Consultant",
                    DOB= DateTime.ParseExact("14/11/1987", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("12/04/2015", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Pune"
                },
                new Employee{
                    EmployeeID = 1004,
                    FirstName="Saba",
                    LastName="Shaikh",
                    Title="SE",
                    DOB= DateTime.ParseExact("03/06/1990", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("02/02/2016", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Pune"
                },
                                new Employee{
                    EmployeeID = 1005,
                    FirstName="Nazia",
                    LastName="Shaikh",
                    Title="SE",
                    DOB= DateTime.ParseExact("08/03/1991", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("02/02/2016", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Mumbai"
                },
                new Employee{
                    EmployeeID = 1006,
                    FirstName="Amit",
                    LastName="Pathak",
                    Title="Consultant",
                    DOB= DateTime.ParseExact("07/11/1989", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("08/08/2014", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Chennai"
                },
                new Employee{
                    EmployeeID = 1007,
                    FirstName="Vijay",
                    LastName="Natrajan",
                    Title="Consultant",
                    DOB= DateTime.ParseExact("02/12/1989", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("01/06/2015", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Mumbai"
                },
                new Employee{
                    EmployeeID = 1008,
                    FirstName="Rahul",
                    LastName="Dubey",
                    Title="Associate",
                    DOB= DateTime.ParseExact("11/11/1993", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("06/11/2014", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Chennai"
                },
                new Employee{
                    EmployeeID = 1009,
                    FirstName="Suresh",
                    LastName="Mistry",
                    Title="Associate",
                    DOB= DateTime.ParseExact("12/08/1992", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("03/12/2014", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Chennai"
                },
                new Employee{
                    EmployeeID = 1010,
                    FirstName="Sumit",
                    LastName="Shah",
                    Title="Manager",
                    DOB= DateTime.ParseExact("12/04/1991", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    DOJ= DateTime.ParseExact("02/01/2016", "dd/MM/yyyy", CultureInfo.InvariantCulture ),
                    City = "Pune"
                }

            };

            // display details of all employees
            Console.WriteLine("display details of all employees");
            foreach (var item in employees.OrderBy(emp => emp.EmployeeID))
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("");
            
            // Display details of all the employee whose location is not Mumbai
            Console.WriteLine(" Display details of all the employee whose location is not Mumbai ");
            foreach (var item in employees.OrderBy(emp => emp.EmployeeID).Where(emp => emp.City != "Mumbai"))
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("");

            //Display details of all the employee whose title is AsstManager
            Console.WriteLine("Display details of all the employee whose title is AsstManager");
            foreach (var item in employees.OrderBy(emp => emp.EmployeeID).Where(emp => emp.Title == "AsstManager"))
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("");

            //Display details of all the employee whose Last Name start with S
            Console.WriteLine("Display details of all the employee whose Last Name start with S");
            foreach (var item in employees.OrderBy(emp => emp.EmployeeID).Where(emp => emp.LastName.StartsWith("S")))
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("");

            // Display a list of all the employee who have joined before 1/1/2015
            Console.WriteLine("Display a list of all the employee who have joined before 1/1/2015");
            foreach (var item in employees.OrderBy(emp => emp.EmployeeID).Where(emp => (DateTime.ParseExact("01/01/2015", "dd/MM/yyyy", CultureInfo.InvariantCulture ) - emp.DOJ).Days > 1 ))
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("");

            // Display a list of all the employee whose date of birth is after 1/1/1990
            Console.WriteLine("Display a list of all the employee whose date of birth is after 1/1/1990");
            foreach (var item in employees.OrderBy(emp => emp.EmployeeID).Where(emp => (DateTime.ParseExact("01/01/1990", "dd/MM/yyyy", CultureInfo.InvariantCulture) - emp.DOB).Days < 1))
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("");

            // Display a list of all the employee whose designation is Consultant and Associate
            Console.WriteLine("Display a list of all the employee whose designation is Consultant and Associate");
            foreach (var item in employees.OrderBy(emp => emp.EmployeeID).Where(emp => emp.Title == "Consultant" || emp.Title == "Associate" ))
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("");

            // Display total number of employees
            Console.WriteLine("Display total number of employees");
            Console.WriteLine(employees.Count);
            Console.WriteLine("");

            // Display total number of employees belonging to “Chennai”
            Console.WriteLine("Display total number of employees belonging to \"Chennai\"");
            Console.WriteLine(employees.Count(emp => emp.City == "Chennai"));
            Console.WriteLine("");

            // Display highest employee id from the list
            Console.WriteLine("Display highest employee id from the list");
            Console.WriteLine( employees.Max(emp => emp.EmployeeID));
            Console.WriteLine("");

            // Display total number of employee who have joined after 1/1/2015
            Console.WriteLine("Display total number of employee who have joined after 1/1/2015");
            Console.WriteLine(employees.Count(emp => (DateTime.ParseExact("01/01/2015", "dd/MM/yyyy", CultureInfo.InvariantCulture) - emp.DOJ).Days > 1));
            Console.WriteLine("");

            // Display total number of employee whose designation is not “Associate”
            Console.WriteLine("Display total number of employee whose designation is not \"Associate\"");
            Console.WriteLine(employees.Count(emp => emp.Title != "Associate"));
            Console.WriteLine("");

            var query = from emp in employees
                        group emp by emp.City // key
                            into groups
                            select
                            new { key = groups.Key, records = groups.ToList() }; // anon object

            // Display total number of employee based on City
            Console.WriteLine("Display total number of employee based on City");
            foreach (var q in query)
            {
                Console.WriteLine(q.key + " : " + q.records.Count);
                
            }
            Console.WriteLine("");
            //???Console.WriteLine(employees.GroupBy(emp => emp.City.ToList()));

            //Display total number of employee based on city and title
            Console.WriteLine("Display total number of employee based on city and title");
            var query2 = from emp in employees
                         group emp by new { emp.City, emp.Title } // key
                             into groups
                             select
                             new { key = groups.Key, records = groups.ToList() }; // anon object

            foreach (var q in query2)
            {
                Console.WriteLine(q.key + " : " + q.records.Count);
            }
            Console.WriteLine("");

            // Display total number of employee who is youngest in the list
            Console.WriteLine("Display total number of employee who is youngest in the list");
            Console.WriteLine(employees.Count( emp => emp.DOB == employees.Min(emp1 => emp1.DOB)));
            Console.WriteLine("");
            Console.ReadKey();
        }
    }
}
